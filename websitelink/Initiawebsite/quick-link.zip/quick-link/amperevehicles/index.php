<?php
session_start();
$user = ""; // please replace with your user
$pass = ""; // please replace with your passwd

// $useroptions = ['cost' => 8,];
// $userhash    = password_hash($user, PASSWORD_BCRYPT, $useroptions);
// $pwoptions   = ['cost' => 8,];
// $passhash    = password_hash($pass, PASSWORD_BCRYPT, $pwoptions);

// echo $userhash;
// echo "<br />";
// echo $passhash;

$base_path = '../../../../iqlf/amperevehicles/';

$user = ""; //prevent the "no index" error from $_POST
$pass = "";
$show_errors = false;
if (isset($_POST['user'])) { // check for them and set them so
    $user = $_POST['user'];
}
if (isset($_POST['pass'])) { // so that they don't return errors
    $pass = $_POST['pass'];
}

$useroptions = ['cost' => 8,]; // all up to you
$pwoptions   = ['cost' => 8,]; // all up to you
$userhash    = password_hash($user, PASSWORD_BCRYPT, $useroptions); // hash entered user
$passhash    = password_hash($pass, PASSWORD_BCRYPT, $pwoptions);  // hash entered pw
$hasheduser  = file_get_contents($base_path . "user.txt"); // this is our stored user
$hashedpass  = file_get_contents($base_path . "pass.txt"); // and our stored password

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (password_verify($user, $hasheduser)) && (password_verify($pass,$hashedpass))) {
    
	$_SESSION["login"] = $hasheduser;
	header("Location: presentation.php");
	
	// counter code
    if (file_exists($base_path . 'count.txt'))
	{
		$fil = fopen($base_path . 'count.txt', "r");
		$dat = fread($fil, filesize($base_path . 'count.txt'));
		fclose($fil);
		$fil = fopen($base_path . 'count.txt', "w");
		fwrite($fil, $dat+1);
	}
	else {
		$fil = fopen($base_path . 'count.txt', "w");
		fwrite($fil, 1);
		fclose($fil);
	}


}
else if($_SERVER['REQUEST_METHOD'] === 'POST' && (!password_verify($user, $hasheduser) || !password_verify($pass,$hashedpass)))
{
    $show_errors = true;
    include $base_path . "login.php";
}
else {
    include $base_path . "login.php";
}