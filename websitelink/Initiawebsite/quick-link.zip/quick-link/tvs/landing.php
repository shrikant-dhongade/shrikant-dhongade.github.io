<?php
	session_start();
	$base_path = '../../../iql-2-files/';
	$hash = file_get_contents($base_path . "user.txt"); // this is our stored user
	if (!isset($_SESSION['login']) || !$_SESSION['login'] == $hash) {
		header("Location: index.php");
	}
?>
<!DOCTYPE html>
<html lang="en" class="gr__getbootstrap_com"><head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="INITIA quick link">
	<meta name="author" content="initiadesigns.com">
	<title>Initia : Quick Link</title>
	<link href="https://fonts.googleapis.com/css?family=Montserrat:500,700&display=swap" rel="stylesheet" />
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/swiper.min.css">
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div class="popup">
	<div class="text-center">
		<h1>Thank you team Skytran<br>for your time!</h1>
		<div class="spinner">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
		</div>
	</div>
</div>
<div class="logo-center-wrapp">
	<img src="img/Initia-logo-no-shadow.png" alt="">
</div>
<div class="page-wrapper df">
	<div class="wrap">
		<a href="presentation.php?name=initia-services-overview" class="ppt-link">
			<div class="icn-wrapper">
				<img src="img/icn/initia-services-overview.png" alt="">
			</div>
			<div class="text-wrapper">Initia<br>Services Overview</div>
		</a>
	</div>
	<div class="wrap">
		<a href="presentation.php?name=commercial-vehicle" class="ppt-link">
			<div class="icn-wrapper">
				<img src="img/icn/commercial-vehicle.png" alt="">
			</div>
			<div class="text-wrapper">Commercial<br>Vehicle Presentation</div>
		</a>
	</div>
	<div class="wrap">
		<a href="presentation.php?name=design-research-case-study" class="ppt-link">
			<div class="icn-wrapper"><img src="img/icn/design-research-case-study.png" style="display: inline-block; height: 65%;" alt=""></div>
			<div class="text-wrapper">Design Research<br>Case Study</div>
		</a>
	</div>
</div>


<script src="js/jquery-1.11.2.min.js"></script>
<!-- Swiper JS -->
<script src="js/swiper.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>