(function() {
    'use strict';

    var swiper = new Swiper('.swiper-container', {
        pagination: {
            el: '.swiper-pagination',
            type: 'fraction',
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        keyboard: true,
        mousewheel: true
    });

    // var vid1 = document.getElementById('vid-1');
    // var vid2 = document.getElementById('vid-2');
    // var vid3 = document.getElementById('vid-3');
    // var vid4 = document.getElementById('vid-4');
    // var vid5 = document.getElementById('vid-5');

    // swiper.on('slideChange', function() {
    //     if(swiper.activeIndex === 56) {
    //         vid2.pause();
    //         vid1.play();
    //     } else if(swiper.activeIndex === 57) {
    //         vid1.pause();
    //         vid2.play();
    //     } else if(swiper.activeIndex == 55 || swiper.activeIndex == 58) {
    //         vid1.pause();
    //         vid2.pause();
    //     }  else if(swiper.activeIndex == 70) {
    //         vid3.pause();
    //     } else if(swiper.activeIndex == 71) {
    //         vid4.pause();
    //         vid3.play();
    //     } else if(swiper.activeIndex === 72) {
    //         vid3.pause();
    //         vid4.play();
    //     } else if(swiper.activeIndex == 73) {
    //         vid4.pause();
    //         vid5.pause();
    //     } else if(swiper.activeIndex == 74) {
    //         vid5.play();
    //     } else if(swiper.activeIndex === 75) {
    //         vid5.pause();
    //     }
    // });

    var $popup = $('.popup');

    setTimeout(function() {
        $popup.removeClass('active');
    }, 3800);
}());