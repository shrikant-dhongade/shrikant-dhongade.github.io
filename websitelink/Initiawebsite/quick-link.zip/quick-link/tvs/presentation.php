<?php
	session_start();
	$base_path = '../../../../iqlf/tvs/';
	$hash = file_get_contents($base_path . "user.txt"); // this is our stored user
	if (!isset($_SESSION['login']) || !$_SESSION['login'] == $hash) {
		header("Location: index.php");
	}
	include $base_path . 'ppt.php';
?>